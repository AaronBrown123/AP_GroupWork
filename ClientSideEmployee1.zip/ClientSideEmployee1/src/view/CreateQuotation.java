package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreateQuotation extends JFrame {
    private EmployeeDashboard parent;

    public CreateQuotation(EmployeeDashboard parent) {
 
    }
}
