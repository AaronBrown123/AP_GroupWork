package Server;

public class SDriver {

	public static void main(String[] args) {
		new Server();

	}

}
